import ts from 'typescript'
import { transformSync } from 'esbuild'

function property(object, name) {
  return object.properties.find((candidate) => candidate.name?.getText().replaceAll(/["']/g, '') === name)
}

function stringProperty(object, name) {
  const found = property(object, name)
  return found && ts.isPropertyAssignment(found) && ts.isStringLiteral(found.initializer) ? found.initializer.text : null
}

export function persistentCall(call) {
  const expression = call.expression.getText()
  if (/\.vault\.(?:writeFile|writeFileGuarded|trashFileGuarded|restoreTrashed)$/.test(expression)) return expression
  if (/\.settings\.set$/.test(expression)) return expression
  if (/\.files\.(?:importDropped|downloadFile)$/.test(expression)) return expression
  if (/\.data\.dataset\([\s\S]*\)\.(?:insert|upsert|update|delete|batch)$/.test(expression)) return expression
  if (/\.data\.transaction$/.test(expression)) return expression
  if (/\.documents\.(?:write|delete)$/.test(expression)) return expression
  if (/\.commands\.executeBatch$/.test(expression)) return expression
  if (/\.drivers\.(?:notes\.(?:writeMarkdown|deleteMarkdown|renameMarkdown)|files\.(?:writeFile|writeBinary|deleteFile)|policy\.(?:saveGuard|appendGuardAudit|applyPluginPreset|skipPluginPreset)|toolbox\.run|browser\.clearData)$/.test(expression)) return expression
  return null
}

export function validatePluginSource(code, file = 'source.tsx') {
  const diagnostics = []
  const tree = ts.createSourceFile(file, code, ts.ScriptTarget.Latest, true, file.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS)
  if (file.endsWith('.tsx')) {
    const output = transformSync(code, { loader: 'tsx', jsx: 'transform', jsxFactory: 'React.createElement', jsxFragment: 'React.Fragment' }).code
    const bindsReact = /^\s*import\s+(?:\*\s+as\s+)?React\b/m.test(code) || /^\s*import\s*\{[^}]*\bReact\b[^}]*\}\s*from/m.test(code) || /^\s*(?:const|let|var)\s+React\b/m.test(code)
    if ((output.includes('React.createElement') || output.includes('React.Fragment')) && !bindsReact) diagnostics.push('renders JSX without binding the runtime React instance')
  }
  const visit = (node) => {
    if (ts.isElementAccessExpression(node) && node.expression.getText(tree) === 'window' && node.argumentExpression && ts.isStringLiteral(node.argumentExpression) && node.argumentExpression.text === 'valley') diagnostics.push('use the injected API instead of window["valley"]')
    if (ts.isObjectLiteralExpression(node) && stringProperty(node, 'sideEffect') === 'read') {
      const run = property(node, 'run')
      if (run) {
        const scan = (child) => {
          if (ts.isCallExpression(child)) {
            const mutation = persistentCall(child)
            if (mutation) diagnostics.push(`read command directly mutates persistent state: ${mutation}`)
          }
          ts.forEachChild(child, scan)
        }
        scan(run)
      }
    }
    if (ts.isJsxOpeningElement(node) || ts.isJsxSelfClosingElement(node)) {
      const tag = node.tagName.getText(tree)
      if (tag === 'select' || tag === 'datalist') diagnostics.push(`use SDK fields instead of <${tag}>`)
      if (tag === 'input') for (const attribute of node.attributes.properties) {
        if (!ts.isJsxAttribute(attribute)) continue
        if (attribute.name.getText(tree) === 'list') diagnostics.push('use SDK ComboField instead of input list')
        if (attribute.name.getText(tree) === 'type' && attribute.initializer && ts.isStringLiteral(attribute.initializer) && ['date', 'datetime-local', 'month', 'week'].includes(attribute.initializer.text)) diagnostics.push('use SDK DateField instead of a native date popup')
      }
    }
    if (ts.isCallExpression(node) && /^(?:h|(?:React\.)?createElement)$/.test(node.expression.getText(tree)) && node.arguments[0] && ts.isStringLiteral(node.arguments[0]) && ['select', 'datalist'].includes(node.arguments[0].text)) diagnostics.push(`use SDK fields instead of createElement('${node.arguments[0].text}')`)
    ts.forEachChild(node, visit)
  }
  visit(tree)
  return diagnostics
}

export function overflowMenuDiagnostics(code, names, file = 'source.tsx') {
  const source = ts.createSourceFile(file, code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)
  const missing = []
  const unseen = new Set(names)
  const ownerOf = (node) => {
    for (let current = node.parent; current; current = current.parent) {
      if (ts.isFunctionDeclaration(current) && current.name) return { name: current.name.text, node: current }
      if ((ts.isArrowFunction(current) || ts.isFunctionExpression(current)) && ts.isVariableDeclaration(current.parent) && ts.isIdentifier(current.parent.name)) return { name: current.parent.name.text, node: current }
    }
    return null
  }
  const arrayFor = (expression, owner) => {
    if (!expression) return null
    if (ts.isArrayLiteralExpression(expression)) return expression
    if (!ts.isIdentifier(expression)) return null
    let found = null
    const visit = (node) => {
      if (ts.isVariableDeclaration(node) && ts.isIdentifier(node.name) && node.name.text === expression.text && node.initializer && ts.isArrayLiteralExpression(node.initializer)) found = node.initializer
      if (!found) ts.forEachChild(node, visit)
    }
    for (let scope = owner; scope && !found; scope = scope.parent) visit(scope)
    return found
  }
  const inspectArray = (array, owner) => {
    const inspectSpread = (expression) => {
      if (ts.isParenthesizedExpression(expression)) return inspectSpread(expression.expression)
      if (ts.isArrayLiteralExpression(expression)) return inspectArray(expression, owner)
      if (ts.isConditionalExpression(expression)) { inspectSpread(expression.whenTrue); inspectSpread(expression.whenFalse) }
    }
    for (const element of array.elements) {
      if (ts.isSpreadElement(element)) { inspectSpread(element.expression); continue }
      if (ts.isObjectLiteralExpression(element) && property(element, 'label') && !property(element, 'icon')) missing.push(`${owner}: menu action is missing a semantic icon`)
    }
  }
  const visit = (node) => {
    if (ts.isCallExpression(node) && ((ts.isIdentifier(node.expression) && node.expression.text === 'openMenu') || (ts.isPropertyAccessExpression(node.expression) && node.expression.name.text === 'openMenu'))) {
      const owner = ownerOf(node)
      if (owner && names.includes(owner.name)) {
        unseen.delete(owner.name)
        const array = arrayFor(node.arguments[0], owner.node)
        if (array) inspectArray(array, owner.name)
        else missing.push(`${owner.name}: menu actions are not statically inspectable`)
      }
    }
    ts.forEachChild(node, visit)
  }
  visit(source)
  return [...missing, ...[...unseen].map((name) => `${name}: menu was not found`)]
}

import { createRequire } from 'node:module'
import path from 'node:path'

export function definePluginTests(options = {}) {
  const root = process.cwd()
  const require = createRequire(path.join(root, 'package.json'))
  const workers = process.env.VALLEY_TEST_MAX_WORKERS
  if (workers !== undefined && (!/^[1-9]\d*$/.test(workers) || !Number.isSafeInteger(Number(workers)))) throw new Error('VALLEY_TEST_MAX_WORKERS must be a positive integer')
  const maximum = workers === undefined ? undefined : Math.min(typeof options.maxWorkers === 'number' ? options.maxWorkers : 2, Number(workers))
  return {
    root,
    test: {
      environment: 'jsdom', include: ['tests/**/*.{test,spec}.{ts,tsx}'],
      globals: true,
      setupFiles: [require.resolve('@valley/plugin-testkit/setup')], maxWorkers: 2, minWorkers: 1,
      ...options,
      ...(maximum === undefined ? {} : { maxWorkers: maximum, minWorkers: Math.min(typeof options.minWorkers === 'number' ? options.minWorkers : 1, maximum) })
    }
  }
}

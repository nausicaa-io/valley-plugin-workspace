import { createRequire } from 'node:module'
import path from 'node:path'

export function definePluginTests(options = {}) {
  const root = process.cwd()
  const require = createRequire(path.join(root, 'package.json'))
  return {
    root,
    test: {
      environment: 'jsdom', include: ['tests/**/*.{test,spec}.{ts,tsx}'],
      globals: true,
      setupFiles: [require.resolve('@valley/plugin-testkit/setup')], maxWorkers: 2, minWorkers: 1,
      ...options
    }
  }
}

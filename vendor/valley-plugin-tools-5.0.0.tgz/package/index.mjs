import fs from 'node:fs/promises'
import path from 'node:path'
import ts from 'typescript'
import { builtinModules, findPackageJSON } from 'node:module'
import { pathToFileURL } from 'node:url'
import { validatePluginSource } from './sourceGates.mjs'
export { validatePluginSource, overflowMenuDiagnostics } from './sourceGates.mjs'

export const PLUGIN_JSX_OPTIONS = { jsx: 'transform', jsxFactory: 'React.createElement', jsxFragment: 'React.Fragment' }

const ignored = new Set(['node_modules', '.git', 'runtime', 'dist', 'out', 'out-tsc', 'vendor'])
export async function sourceFiles(root) {
  const files = []
  for (const entry of await fs.readdir(root, { withFileTypes: true })) {
    if (/claude/i.test(entry.name) || entry.name.startsWith('.plugin-build-') || ignored.has(entry.name) || entry.isSymbolicLink()) continue
    const file = path.join(root, entry.name)
    if (entry.isDirectory()) files.push(...await sourceFiles(file))
    else if (/\.[cm]?[jt]sx?$/.test(file)) files.push(file)
  }
  return files
}

export async function readPluginLocales(root, config, manifest, runtime = false) {
  const declared = config.locales
  if (JSON.stringify(Object.keys(declared ?? {}).sort()) !== JSON.stringify(['en', 'de', 'es', 'fr', 'zh-CN'].sort())) throw new Error('config.locales must declare all five package languages')
  if (!declared || typeof declared !== 'object' || Array.isArray(declared) || !declared.en) throw new Error('config.locales must declare an English catalog')
  const catalogs = {}
  const base = await fs.realpath(root)
  for (const [locale, file] of Object.entries(declared)) {
    if (!/^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(locale) || file !== `runtime/locales/${locale}.json`) throw new Error(`Invalid locale declaration: ${locale}`)
    const source = path.join(base, runtime ? file : `locales/${locale}.json`)
    const actual = await fs.realpath(source)
    const relative = path.relative(base, actual)
    if (relative.startsWith('..') || path.isAbsolute(relative) || (await fs.lstat(source)).isSymbolicLink()) throw new Error(`Locale catalog escapes its package: ${locale}`)
    const size = (await fs.stat(actual)).size
    if (size > 2 * 1024 * 1024) throw new Error(`Locale catalog exceeds 2 MB: ${locale}`)
    const catalog = JSON.parse(await fs.readFile(actual, 'utf8'))
    if (!catalog || typeof catalog !== 'object' || Array.isArray(catalog) || Object.keys(catalog).length > 20000 || Object.entries(catalog).some(([key, value]) => !key || typeof value !== 'string')) throw new Error(`Invalid string catalog: ${locale}`)
    catalogs[locale] = catalog
  }
  const keys = Object.keys(catalogs.en).sort().join('\0')
  for (const [locale, catalog] of Object.entries(catalogs)) {
    if (Object.keys(catalog).sort().join('\0') !== keys) throw new Error(`Locale key parity failed: ${locale}`)
    for (const [key, value] of Object.entries(catalog)) {
      const placeholders = (text) => [...text.matchAll(/\{\{([^}]+)\}\}/g)].map((match) => match[1]).sort().join('\0')
      if (placeholders(value) !== placeholders(catalogs.en[key])) throw new Error(`Locale placeholder parity failed: ${locale}.${key}`)
    }
  }
  for (const field of ['name', 'description']) {
    if (catalogs.en[`manifest.${field}`] !== manifest[field]) throw new Error(`English manifest.${field} must match manifest ${field}`)
  }
  return catalogs
}

export async function checkPlugin(root) {
  const pkg = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8'))
  const manifest = JSON.parse(await fs.readFile(path.join(root, 'manifest.json'), 'utf8'))
  const config = JSON.parse(await fs.readFile(path.join(root, 'config.json'), 'utf8'))
  if (manifest.apiVersion !== 5 || pkg.version !== manifest.version) throw new Error('Package and manifest must agree on version and apiVersion 5')
  if ('nameKey' in manifest || 'descriptionKey' in manifest) throw new Error('Manifest identity translations belong in package locales')
  await readPluginLocales(root, config, manifest)
  if (config.searchSources?.some((source) => source.source === 'dataset')) {
    const sdkManifestPath = findPackageJSON('@valley/plugin-sdk', pathToFileURL(path.join(root, 'package.json')))
    const sdkManifest = JSON.parse(await fs.readFile(sdkManifestPath, 'utf8'))
    const schemaPath = sdkManifest.exports?.['./pluginSchema']?.import
    if (typeof schemaPath !== 'string' || !schemaPath.startsWith('./')) throw new Error('Installed SDK must export the plugin schema validator')
    const { validateDatasetSearchSources } = await import(pathToFileURL(path.resolve(path.dirname(sdkManifestPath), schemaPath)).href)
    if (typeof validateDatasetSearchSources !== 'function' || !validateDatasetSearchSources(manifest.id, config.datasets ?? [], config.searchSources)) throw new Error('Invalid dataset search source or join declaration')
  }
  if (config.main !== 'runtime/index.js') throw new Error('config.main must be runtime/index.js')
  if (config.indexState !== undefined && config.indexState !== 'scoped') throw new Error('Invalid index state declaration')
  if (config.runtime?.ui !== 'runtime/index.js') throw new Error('config.runtime.ui must be runtime/index.js')
  if (config.runtime?.backend && config.runtime.backend !== 'runtime/backend.js') throw new Error('config.runtime.backend must be runtime/backend.js')
  if (config.runtime?.activation !== undefined) {
    const sdkManifestPath = findPackageJSON('@valley/plugin-sdk', pathToFileURL(path.join(root, 'package.json')))
    const sdkManifest = JSON.parse(await fs.readFile(sdkManifestPath, 'utf8'))
    const runtimePath = sdkManifest.exports?.['./pluginRuntime']?.import
    if (typeof runtimePath !== 'string' || !runtimePath.startsWith('./')) throw new Error('Installed SDK must export the runtime activation validator')
    const { validatePluginRuntimeActivation } = await import(pathToFileURL(path.resolve(path.dirname(sdkManifestPath), runtimePath)).href)
    if (!config.runtime.backend || typeof validatePluginRuntimeActivation !== 'function' || !validatePluginRuntimeActivation(config.runtime.activation)) throw new Error('Invalid backend activation declaration')
  }
  if (config.assets && config.assets !== 'runtime/assets') throw new Error('config.assets must be runtime/assets')
  for (const entry of config.storageInventory ?? []) {
    if (entry.backup !== undefined && typeof entry.backup !== 'boolean') throw new Error('Storage backup policy must be a boolean')
    if (entry.index !== undefined && typeof entry.index !== 'boolean') throw new Error('Storage index policy must be a boolean')
    const location = entry.location
    if (entry.backup === false && !location) throw new Error('Backup exclusions require a literal storage location')
    if (entry.index === false && location?.area !== 'vault') throw new Error('Index exclusions require a literal vault storage location')
    if (!location) continue
    if (!['metadata', 'vault'].includes(location.area) || typeof location.path !== 'string' || !location.path || path.isAbsolute(location.path) || /^[A-Za-z]:/.test(location.path) || location.path.includes('\\') || location.path.includes('\0') || location.path.split('/').some(part => !part || part === '.' || part === '..' || /[*?[]/.test(part))) throw new Error('Storage inventory locations must be contained literal paths')
    const permission = config.permissions?.storage
    if (location.area === 'vault' ? !permission?.vault || location.path.split('/').includes('.valley') : !permission?.metadata?.some(prefix => location.path === prefix || location.path.startsWith(prefix + '/'))) throw new Error('Storage inventory location is outside the declared permissions')
  }
  const dependencies = new Set(Object.keys({ ...pkg.dependencies, ...pkg.devDependencies, ...pkg.peerDependencies }))
  for (const file of await sourceFiles(root)) {
    const code = await fs.readFile(file, 'utf8')
    if (path.relative(root, file).startsWith(`src${path.sep}`)) {
      const diagnostics = validatePluginSource(code, file)
      if (diagnostics.length) throw new Error(`${file}: ${diagnostics.join('; ')}`)
    }
    const tree = ts.createSourceFile(file, code, ts.ScriptTarget.Latest, true)
    const inspect = (node) => {
      const specifier = (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) ? node.moduleSpecifier
        : ts.isImportTypeNode(node) && ts.isLiteralTypeNode(node.argument) ? node.argument.literal
        : ts.isImportEqualsDeclaration(node) && ts.isExternalModuleReference(node.moduleReference) ? node.moduleReference.expression
        : ts.isCallExpression(node) && (node.expression.kind === ts.SyntaxKind.ImportKeyword || node.expression.getText(tree) === 'require') ? node.arguments[0] : null
      if (specifier && ts.isStringLiteral(specifier)) {
        const name = specifier.text
        if (path.relative(root, file).startsWith(`src${path.sep}`) && (name.startsWith('node:') || builtinModules.includes(name))) throw new Error(`${file}: runtime process modules must use the injected API: ${name}`)
        if (/^@(shared|renderer|testing)(\/|$)/.test(name)) throw new Error(`${file}: host import ${name}`)
        if (name.startsWith('.')) {
          const relative = path.relative(root, path.resolve(path.dirname(file), name))
          if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error(`${file}: import escapes package: ${name}`)
        } else if (!name.startsWith('node:')) {
          const dependency = name.startsWith('@') ? name.split('/').slice(0, 2).join('/') : name.split('/')[0]
          if (!dependencies.has(dependency) && !['fs', 'path', 'os', 'url', 'fs/promises'].includes(name)) throw new Error(`${file}: undeclared dependency ${dependency}`)
        }
      }
      if (ts.isPropertyAccessExpression(node) && node.expression.getText(tree) === 'window' && node.name.text === 'valley') throw new Error(`${file}: use the injected API`)
      ts.forEachChild(node, inspect)
    }
    inspect(tree)
  }
  return { pkg, manifest, config }
}

export async function buildPlugin({ root = process.cwd(), outDir = path.join(root, 'runtime'), mode = 'production' } = {}) {
  const { build } = await import('esbuild')
  root = await fs.realpath(root)
  const { pkg, config } = await checkPlugin(root)
  const temporary = await fs.mkdtemp(path.join(path.dirname(outDir), '.plugin-build-'))
  try {
    const custom = pkg.valley?.build ? (await import(path.join(root, pkg.valley.build))).default : {}
    const { backendOptions, ...options } = (typeof custom === 'function' ? await custom({ root, outDir: temporary }) : custom) ?? {}
    const result = await build({
      absWorkingDir: root, entryPoints: [path.join(root, 'src/index.tsx')], outfile: path.join(temporary, 'index.js'),
      bundle: true, format: 'esm', platform: 'browser', target: 'es2020', ...PLUGIN_JSX_OPTIONS, conditions: ['production'],
      loader: { '.css': 'text' }, metafile: true, minify: mode === 'production', logLevel: 'silent', ...options
    })
    if (config.runtime?.backend) {
      const backend = await build({ absWorkingDir: root, entryPoints: [path.join(root, 'src/backend/index.ts')], outfile: path.join(temporary, 'backend.js'), bundle: true, format: 'esm', platform: 'browser', target: 'es2022', metafile: true, minify: mode === 'production', logLevel: 'silent', ...backendOptions })
      result.warnings.push(...backend.warnings)
      Object.assign(result.metafile.inputs, backend.metafile.inputs)
    }
    if (result.warnings.length) throw new Error(result.warnings.map((warning) => warning.text).join('\n'))
    for (const input of Object.keys(result.metafile.inputs)) {
      if (/^(?:\(disabled\)|[a-zA-Z][\w-]*):/.test(input) && !path.isAbsolute(input)) continue
      const resolved = await fs.realpath(path.resolve(root, input))
      const relative = path.relative(root, resolved)
      if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error(`Bundle input escapes package: ${input}`)
    }
    if (config.locales) {
      await fs.mkdir(path.join(temporary, 'locales'), { recursive: true })
      for (const locale of Object.keys(config.locales)) await fs.copyFile(path.join(root, 'locales', `${locale}.json`), path.join(temporary, 'locales', `${locale}.json`))
    }
    if (config.assets) await fs.access(path.join(temporary, 'assets'))
    if (!config.build?.bundleReact && Object.keys(result.metafile.inputs).some((file) => /node_modules\/react(-dom)?\//.test(file))) throw new Error('Bundle contains React; use api.React')
    await replaceDirectory(temporary, outDir)
    return { outDir, metafile: result.metafile }
  } finally { await fs.rm(temporary, { recursive: true, force: true }) }
}

export async function replaceDirectory(staged, destination) {
  const backup = `${staged}.previous`
  let backedUp = false
  try { await fs.rename(destination, backup); backedUp = true } catch (error) { if (error.code !== 'ENOENT') throw error }
  try { await fs.rename(staged, destination) } catch (error) {
    if (backedUp) {
      try { await fs.rename(backup, destination) } catch (restoreError) {
        throw new AggregateError([error, restoreError], `Runtime replacement and restoration failed; previous runtime preserved at ${backup}`)
      }
    }
    throw error
  }
  if (backedUp) await fs.rm(backup, { recursive: true, force: true })
}

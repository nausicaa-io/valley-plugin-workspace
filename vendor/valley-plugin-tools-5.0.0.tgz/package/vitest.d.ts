export function definePluginTests(options?: Record<string, unknown>): { test: Record<string, unknown> }

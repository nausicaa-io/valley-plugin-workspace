#!/usr/bin/env node
import { spawnSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { buildPlugin, checkPlugin } from './index.mjs'
const require = createRequire(import.meta.url)
const command = process.argv[2]
const run = (file, args) => {
  const result = spawnSync(process.execPath, [require.resolve(file), ...args], { stdio: 'inherit', cwd: process.cwd(), env: process.env })
  if (result.error) throw result.error
  if (result.status !== 0) process.exit(result.status ?? 1)
}
for (const stage of command === 'check' ? ['lint', 'typecheck', 'test', 'build'] : [command]) {
  if (stage === 'lint') await checkPlugin(process.cwd())
  else if (stage === 'typecheck') run('typescript/bin/tsc', ['--noEmit', '-p', 'tsconfig.json'])
  else if (stage === 'test') run('vitest/vitest.mjs', ['run', ...process.argv.slice(3)])
  else if (stage === 'build') await buildPlugin()
  else throw new Error('Usage: valley-plugin <check|lint|typecheck|test|build>')
}
